INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '지난주에 방문했습니다','직원들도 친절하고 방도 만족했습니다 ~ 다만 난방이 조금 아쉽더라구요 ! 다음에 재방문의사 있어요 ~', 'choaha91', 'No file', 1, 4.5, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '난방이 잘 안되는것 같아요','밤에 좀 쌀쌀해서 잠을 뒤척였네요. 난방문제좀 해결해주세요 !', 'maniac892','No file', 1, 2, 'B201', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '뭐 이런 방이 다 있냐?','벽지는 다 뜯어져 있고 화장실 청소도 제대로 안되있어요 진짜 극혐이네요 다시는 안갑니다', 'kunst54', 'No file', 1, 0.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '직원들 친절해서 맘에 들어요','다른건 모르겠고 직원들이 너무 친절합니다. 새벽에 아기때문에 불렀는데 친절하게 잘 도와주셨어요 ~ 너무 감사합니다', 'paladin111', 'No file', 1, 5, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, 'B201객실 이용후기입니다','방은 일단 깨끗하고 4명이서 갔는데 충분히 넓었습니다. 조용하고 직원들도 친절해서 잘 놀다갑니다','minbc992', 'No file', 1, 4.0, 'B201', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '방이 깨끗해요','건물은 오래된거 같은데 티가 안날만큼 방은 깨끗합니다. 다만 옆방에 묵은 사람들이 좀 시끄러웠습니다. 아쉽네요', 'yeejin800', 'No file', 1, 3.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '청소 제대로 하는거 맞아요?','아니 무슨 호텔에서 바퀴벌레가 나옵니까? 장난하세요? 같이 간 와이프가 너무 놀랐습니다. 청소좀 똑바로 하세요', 'geong12', 'No file', 1, 1.0, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '수돗물에서 유충이 나왔어요...','밤에 라면 끓여먹을려고 물 받았는데 물속에 뭐가 꿈틀거리는거에요... 자세히 보니까 1cm길이정도 유충이 움직이고 있더라구요... 이거 심각한거 아닌가요? 연락주세요 빨리..', 'ddalgi76', 'No file', 1, 0.5, 'B202', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '카운터에 근무하는 이병한 직원 칭찬하고 싶습니다','호텔 식당에서 밥먹다가 모르고 결혼반지를 잃어버렸는데... 말씀드리니까 방송도 해주시고 정말 자기일인거 마냥 열심히 찾아주시더라구요 결국 반지는 제 가방에 있었는데 ㅜㅜ 정말 너무 죄송하고 감사합니다.', 'hwangyoungju90', 'No file', 1, 5, 'B202', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '잘 쉬다갑니다 !!','방도 깨끗하고 직원들도 친절하고.. 가격은 좀 비싸지만 만족하고 갑니다 ~','jungda52','No file', 1, 4, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '굳굳굳 좋아용','위치도 좋고 깨끗해요 굳굳', 'dddkmss77', 'No file', 1, 5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '위치가 진짜 사기에요', '연남동/홍대 좋아하시는 분들에게 정말 추천해요 방도 깔끔하고 조용하고 연남동 번화가까지 걸어서 5분도 안걸려요 정말 좋아요', 'moonriver33', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '예상보다 너무 좋았어요', '별로 기대 안했는데 예상보다 좋았어용 체크아웃 시간도 배려해주셔서 조금 더 편하게 있을 수 있었어요 :)', 'geong12', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '위치만 보고 왔는데...', '기대 안하고 위치만 보고 갔는데요 나가면 바로 중심지입니다 공원2분 전철역3분입니다', 'minbc992', 'No file', 1, 3.5, 'B201', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '관리자님 감사합니다', '항상 정말 빠르게 응답해주시는 호스트님.. 항상 부족한거 있으면 바로바로 채워주시고 정말 감동이었습니다. 묵는동안 불편함 없었고 너무 감사했습니다.', 'yeejin800', 'No file', 1, 5, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '쾌적합니다', '신촌역이랑 정말 가깝고 가구랑 시설 너무 훌륭했습니다. 가구도 신설이고 쾌적하며 너무 따뜻해서 좋았어요 ㅎㅎ', 'jungjongs71', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '가격이 좀 비싸네요', '처음에 가격이 좀 비싸서 꺼려졌는데 너무 깨끗하고 방 분위기도 너무너무 좋았어요', 'leejang7', 'No file', 1, 4.5, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '좋아요', '넓고 깨끗하고 위치좋고 좋습니다', 'kimjy577', 'No file', 1, 3.5, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '이용후기 2주만에 작성하네요', '2주전에 방문했었는데 재예약을 할 정도로 너무 좋습니다. 깨끗함은 물론이고 직원들이 너무 친절해요 ~', 'choaha91', 'No file', 1, 4.5, 'B201', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '일때문에 묵었는데', '아무리 위치가 좋다지만 가격은 오지게 비싼거 같아요.. 직원들은 친절합니다', 'maniac892', 'No file', 1, 2.0, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '추천 만땅드려용', '길이 약간 헷갈렸지만 그래도 찾기 쉬웠구요!! 방도 너무 분위기좋고 아늑해서 좋았어요!! 다시 가고싶은 곳이라 추천만땅드려용', 'dddkmss77', 'No file', 1, 4.5, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '위치 완벽', '위치가 완벽하고 방도 사진과 똑같이 크고 예뻤습니다. 인테리어도 잘 꾸며놓으셨더라구요 다음에 오면 또 오고 싶어요 ㅎㅎ', 'sunshine574', 'No file', 1, 4.5, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '방이 깔끔하고 이뻐요', '깔끔하고 이쁘고 침대도 푹신하고 좋았어요! 다만 화장실이 좁은거 같아여... 샤워할때 좀 불편했네용', 'ddalgi76', 'No file', 1, 3.0, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, 'Super great Place and Host, Thanks!', 'The place is great and I can just recommend it to anybody. Location is great with many restaurants and parks around and not far away from hongdea.', 'richman23', 'No file', 1, 4.0, 'B201', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '침대 스프링이 이상해요', '방은 깨끗하고 좋았는데 침대스프링이 이상하게 푹푹 꺼져서 좀 불편했습니다.', 'leejang7', 'No file', 1, 2.5, 'B202', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '신촌역 !!', '신촌역의 좋은 위치에 편안한 침구입니다 !', 'jungjongs71', 'No file', 1, 4.0, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '직원들이 친절해요', '위치가 너무 좋고 직원들 친절합니다.', 'yeejin800', 'No file', 1, 3.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '두번째 후기 남깁니다', '두번째 방문입니다. 역시 실망시키지 않네요 좋습니다', 'kunst54', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '냉장고가 고장나서 불편했습니다', '냉장고가 고장나서 아침에 먹을 샌드위치 같은거는 못 샀네요', 'kimjy577', 'No file', 1, 2.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '방 사진이랑 실물이랑 너무 똑같아요', '홈페이지에 방 사진이랑 실물이랑 거의 똑같습니다 ! 너무 예뻤어요. 보일러도 잘되서 추운겨울에 딱 !', 'choaha91', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '조용 깨끗 위치최고 아늑', '도심지에 위치했지만 조용하고 깨끗합니다. 방도 매우 아늑하구요. 묵을만 합니다', 'minbc992', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '방이 깨끗하네요', '방이 진짜 너무 깨끗하네요 청소 노하우좀 알려주세요...', 'hwangyoungju90', 'No file', 1, 3.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '분위기 좋아요 !', '생각보다 멀었는데 제가 짐이 많아서 그렇게 느낀것 같고 방 분위기가 너무 좋아요 ! 최고입니다 !', 'ddalgi76', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '시설 좋습니다', '직원분들도 친절하시구요 청결하고 숙소 분위기, 시설 좋습니다 추천해요', 'jungjongs71', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '사진하고 똑같아요', '사진과 그대로고 침대가 깨끗하고 난방을 잘해주셔서 따뜻하게 계속 지낼 수 있었어요 감사합니다', 'dddkmss77', 'No file', 1, 5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '방이 깔끔하고 좋았습니다 ~', '방이 매우 깔끔해요 ~ 냄새에 민감한 편인데 방 내부와 침구에서 좋은 냄새가 나서 좋았어요 !', 'hwangyoungju90', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, 'ありがとうございました!', '説明にあるようにﾎﾝﾃﾞ駅からそれなりに歩きますが大通りも近く一人でも大丈夫でした! 神経質な方はﾊﾞｽﾙｰﾑとﾄｲﾚがきになると思います｡', 'richman23', 'No file', 1, 4.5, 'B201', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '주변 놀곳이 많아서 좋아요', '위치가 위치인만큼 주변에 놀곳이 많습니다 ! 너무 좋아요 !', 'paladin111', 'No file', 1, 4.5, 'B202', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '잠 자기는 괜찮은거 같아요', '케바케인건지는 모르겠는데 제가 잤던 방은 약간 꿉꿉함이 느껴졌습니다 잠만 자기 괜찮은듯..', 'leejang7', 'No file', 1, 1.5, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '와이파이 비번이 머죠?', '와이파이 비번을 어디다가 써놓으신 건가요? 몰라서 한참 헤맸습니다', 'kunst54', 'No file', 1, 1.0, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '사진이랑 실물이랑 똑같아요', '숙소가 실물도 사진처럼 너무 이쁘고 편안했습니다. 화장실도 넓고 청결했어요 덕분에 잘 쉬고 갑니다 ♡', 'sunshine574', 'No file', 1, 4.5, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '직원들이 너무 친절해요', '직원분들이 정말 친절하세요 ! 고민하지 마시고 예약하세요 추천드려요 ~', 'geong12', 'No file', 1, 5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '위치 대박...', '위치가 신촌이라 근처에 여러 맛집들이 많고 지하철 타고 가시는걸 추천드립니다 숙소는 아늑했어요', 'yeejin800', 'No file', 1, 3.5, 'B201', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '장난하세요?', '밤 늦게 체크인 가능하다고 하셔놓고 갔더니 카운터에 아무도 안 계시더라구요? 앞에서 30분이나 기다렸습니다 ! 정말 장난하세요? 오랜만에 휴가인데 기분 잡쳤네요', 'kimjy577', 'No file', 1, 0.5, 'B202', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '좋았슴당', '가격은 좀 비싸지만 괜찮았어요', 'minbc992', 'No file', 1, 2.5, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '2명이서 갔는데 너무 넓어서 좋았어요 !', '남자친구랑 갔는데 방이 너무 넓어서 좋았어요 ~ 둘이서 쓰기엔 좀 아깝더라구요 ㅎㅎ', 'ddalgi76', 'No file', 1, 3.5, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '신속한 응대가 좋았어요', '신속한 응대가 좋았고 친절하셨습니다. 학생들이 놀러가기에 정말 좋은 위치인거 같아요 !', 'hwangyoungju90', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '예상보다 괜찮은듯', '예상보다 더 좋았고 인테리어도 깔끔하고 좋았어요 다만 테이블위에 화병(?)이 좀 거슬렸어요 ㅠㅠ 그래도 좋았습니다 !', 'dddkmss77', 'No file', 1, 3.5, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '공항가기에 괜찮습니다', '신촌역과 가깝다보니 공항가기 괜찮고 방도 깔끔했어요', 'geong12', 'No file', 1, 4.5, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '여름이라 그런가... 모기가..', '여름이라 어쩔 수 없는건지 모기가 넘 많았어요 ㅠㅠ 좋은 평가는 못 드릴꺼 같습니다', 'ddalgi76', 'No file', 1, 1.5, 'A101', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '가격대비 별로인거 같아요', '방도 깔끔하고 직원들도 친절하고 다 좋은데 가격이 너~~~무 비싸요 ㅜㅜ 진짜 너무 비싸요 가격이 더 싸면 정말 좋을듯', 'leejang7', 'No file', 1, 2.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '신촌역 3분거리', '신촌역 도보 3분거리+이쁜 인테리어 보고 지체없이 예약했는데요! 사진에서 보는것과 그대로인 이쁜 집이었어요 !! 수건도 아주 넉넉하구요 굿굿 !', 'maniac892', 'No file', 1, 5, 'B201', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '생각보다 방이 좁네요', '사진으로는 방이 꽤 넓어보였는데 막상 가보니 생각보다 좀 좁았습니다. 그래도 깨끗해서 만족해요', 'kunst54', 'No file', 1, 3.5, 'B201', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '위치가 정말 대박인듯', '다른것도 괜찮은데 뭣보다 위치가 정말 대박.. 각종 편의시설이 도보 5분거리에 다 있습니다 여기서 살고 싶다', 'choaha91', 'No file', 1, 5, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '잘 이용하고 갑니다', '잘 이용하구가요 ㅎㅎㅎ 너무좋았어요 !!!', 'parkjisung1', 'No file', 1, 4.5, 'C301', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '너무 아늑하고 좋았어요 ~ !', '너무 아늑하고 좋았어요 ~ 잘 쉬다 갑니다 ! 번창하세요 ^^', 'yeejin800', 'No file', 1, 5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '인테리어가 괜찮네요', '조명도 근사하고 굉장히 아늑했습니다. 신촌역이랑 가깝구 바로 앞에 편의점도 있어욜 !', 'hwangyoungju90', 'No file', 1, 5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '위치부터 숙소컨디션까지 괜찮습니다', '정말 대만족 ! 서울오면 무조건 여기에요 !', 'ddalgi76', 'No file', 1, 5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, 'Great location, comfortable bed, all the necessities. No complaints !', 'Beautiful place and very good location! We would gladly come again (hopefully for a longer stay). Thank you to the awesome Hosts!', 'richman23', 'No file', 1, 4.5, 'A102', SYSDATE);
INSERT INTO REVIEW (RNO, RTITLE, RCONTENT, MID, RFILENAME, RISDELETE, RRATING, GNAME, RREGDATE)
VALUES (REVIEWBOARD_SEQ.NEXTVAL, '사진이랑 똑같아요', '사진이랑 정말 똑같아요. 있을거 다 있고 깨끗하고 또 좋은 위치에 있어서 편하게 있다가 갑니다 :)', 'parkjisung1', 'No file', 1, 3.5, 'A102', SYSDATE);


